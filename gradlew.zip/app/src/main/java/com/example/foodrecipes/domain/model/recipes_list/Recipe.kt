package com.example.foodrecipes.domain.model.recipes_list

data class Recipe(
    val id: Int,
    val title: String,
    val image: String
)