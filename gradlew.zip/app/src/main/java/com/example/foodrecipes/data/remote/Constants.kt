package com.example.foodrecipes.data.remote

object Constants {
    const val BASE_URL = "https://api.spoonacular.com/recipes/"
    const val IMAGE_BASE_URL = "https://spoonacular.com/cdn/ingredients_250x250/"
    const val PARAM_ID = "id"
}